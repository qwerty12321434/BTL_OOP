/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import Class.DSLuong;
import Class.DSAccount;
import Class.DSNhanVien;
import gui.Login;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 *
 * @author huyle
 */
public class main {

    public static void main(String[] args) throws FileNotFoundException {
        DSLuong dsL = new DSLuong();
        DSAccount dsA = new DSAccount();
        Scanner in = new Scanner(new File("C:\\Users\\Lenovo\\Downloads\\EMS-OOP-BTL-master\\EMS-OOP-BTL-master\\BTL_OOP_GUI\\src\\Class\\data.txt"));
        DSNhanVien dSNhanVien = new DSNhanVien(dsA, dsL);

        // Load dữ liệu từ file (nếu tồn tại)
        File file = new File("C:\\Users\\Lenovo\\Downloads\\EMS-OOP-BTL-master\\EMS-OOP-BTL-master\\BTL_OOP_GUI\\src\\Class\\dsLuong.txt");
        if (file.exists()) {
            dsL.loadFromFile("C:\\Users\\Lenovo\\Downloads\\EMS-OOP-BTL-master\\EMS-OOP-BTL-master\\BTL_OOP_GUI\\src\\Class\\dsLuong.txt");
        } else {
            System.out.println("File dữ liệu không tồn tại. Sử dụng dữ liệu mặc định.");
        }
//        while (in.hasNextLine()) {
//            String s = in.nextLine();
//            System.out.println(s);
//            String[] line = s.trim().split(",");
//            for (String x : line) {
//                System.out.println(x);
//            }
//            String tenNV = line[0];
//            String chucVu = line[1];
//            String GioiTinh = line[2];
//            String email = line[3];
//            String SoDT = line[4];
//            String NgaySinh = line[5];
//            String NgayBatDau = line[6];
//            NhanVien nv = new NhanVien(tenNV, chucVu, GioiTinh, email, SoDT, NgaySinh, NgayBatDau);
//            //System.out.println(tenNV + " " + chucVu + " " + GioiTinh + " " + email + " " + SoDT + " " + NgaySinh + " " + NgayBatDau);
//            dSNhanVien.addDSNhanVien(nv);
//        }
//        for (Luong x : dsL.getDSLuong()) {
//            System.out.println(x);
//        }
        new Login(dSNhanVien, dsA, dsL).setVisible(true);
    }

}
